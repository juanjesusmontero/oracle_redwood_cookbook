/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
], ActionChain => {
  'use strict';

  class checkDirtyDataFlag extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      if ($page.variables.dirtyDataFlag) {
        const callFunctionResult = await $page.functions.checkWithUser();

        if (callFunctionResult.callOpenDialog === 'DISCARD') {
          return { cancelled: false };
        } else {
          return { cancelled: true };
        }
      } else {
        return { cancelled: false };
      }
    }
  }

  return checkDirtyDataFlag;
});
