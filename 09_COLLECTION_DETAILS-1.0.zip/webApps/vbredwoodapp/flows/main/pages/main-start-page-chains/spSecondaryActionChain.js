/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions',
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSecondaryActionChain extends ActionChain {

    /**
     * Notifiy secondary action is triggered
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.detail Action detail
     */
    async run(context, { detail }) {
      const { $page } = context;

      // Assign the action detail to the message
      $page.variables.messages = "summary: Secondary Action Performed; " + "detail: secondaryItem: " + detail.secondaryItem;

      // Show toast messages
      await Actions.callComponentMethod(context, {
        selector: '#cdMessages',
        method: 'open',
      }, { id: 'showToast' });
    }
  }

  return spSecondaryActionChain;
});
