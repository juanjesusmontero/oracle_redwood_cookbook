/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions',
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class onSelectedChanged extends ActionChain {

    /**
     * Update selection when selected items change
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      const callCheckDirtyDataFlagChain = await Actions.callChain(context, {
        chain: 'checkDirtyDataFlag',
      });

      if (callCheckDirtyDataFlagChain) {
        $page.variables.selected = $page.variables.prevSelected;
      } else {

        $page.variables.dirtyDataFlag = false;

        $page.variables.prevSelected = $page.variables.selected;

        $page.variables.selectedItemKeys = Array.from($page.variables.selected.values()).reverse();
      }
    }
  }

  return onSelectedChanged;
});
