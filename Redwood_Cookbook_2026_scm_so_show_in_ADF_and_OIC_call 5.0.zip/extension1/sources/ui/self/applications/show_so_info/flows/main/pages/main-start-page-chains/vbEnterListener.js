define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.varHeight',
          '$page.variables.varTotal',
          '$page.variables.varWeight',
          '$page.variables.varVolTotal',
          '$page.variables.varWeightTotal',
          '$page.variables.varWidth',
          '$page.variables.varLength',
        ],
      });

      const response = await Actions.callRest(context, {
        endpoint: 'site_SCM_SO_INFO:sales_order/getSO_ChildLines',
        uriParams: {
          fields: 'ProductId,OrderedQuantity,InventoryOrganizationId,HeaderId,LineId',
          OrderKey: $variables.pHeaderId,
        },
        responseBodyFormat: 'json',
      });

      const results2 = await ActionUtils.forEach(response.body.items, async (current_item, index) => {

        $variables.varQuery = 'ItemId=' + current_item.ProductId + ' and OrganizationId=' + current_item.InventoryOrganizationId;
        $variables.varOrgId = current_item.InventoryOrganizationId;
        $variables.varItemId = current_item.ProductId;
        $variables.varQuantity = current_item.OrderedQuantity;

        const response3 = await Actions.callRest(context, {
          endpoint: 'site_SCM_SO_INFO:sn_items/getall_itemsV2',
          uriParams: {
            q: $variables.varQuery,
            onlyData: true,
            totalResults: true,
            fields: 'ItemId,OrganizationId,ItemNumber,DimensionUOMValue,UnitWidthQuantity,UnitLengthQuantity,UnitHeightQuantity,WeightUOMValue,UnitWeightQuantity,VolumeUOMValue,UnitVolumeQuantity',
          },
          responseBodyFormat: 'json',
        });//


        $variables.varWeightUOM = response3.body.items[0].WeightUOMValue;
        $variables.varDimUOM = response3.body.items[0].DimensionUOMValue;

        $variables.varWeight = response3.body.items[0].UnitWeightQuantity;
        $variables.varWidth = response3.body.items[0].UnitWidthQuantity;
        $variables.varHeight = response3.body.items[0].UnitHeightQuantity;
        $variables.varLength = response3.body.items[0].UnitLengthQuantity;
        $variables.varWeightTotal = $variables.varWeightTotal + ($variables.varQuantity * $variables.varWeight);
        $variables.varVolTotal = $variables.varVolTotal + ($variables.varQuantity * $variables.varWidth * $variables.varHeight * $variables.varLength);

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          message: 'varWeightTotal:' + $variables.varWeightTotal
            + ' || varVolTotal:' + $variables.varVolTotal
            + ' || varWeight:' + $variables.varWeight
            + ' || varWidth:' + $variables.varWidth
            + ' || varWeightTotal:' + $variables.varHeight,
          type: 'info',
          displayMode: 'persist',
        });



      }, { mode: 'serial' });
    }
  }

  return vbEnterListener;
});
