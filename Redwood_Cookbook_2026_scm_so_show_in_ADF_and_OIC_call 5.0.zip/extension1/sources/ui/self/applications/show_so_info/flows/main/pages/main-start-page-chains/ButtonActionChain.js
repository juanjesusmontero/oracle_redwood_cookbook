define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'site_SCM_SO_INFO:serv_name_oic/get',
        uriParams: {
          pHeaderId: $variables.pHeaderId,
        },
      });

      $variables.varShowMessage = 'MESSAGE FROM SaaS App UI extension:' + response.body.message;
    }
  }

  return ButtonActionChain;
});
