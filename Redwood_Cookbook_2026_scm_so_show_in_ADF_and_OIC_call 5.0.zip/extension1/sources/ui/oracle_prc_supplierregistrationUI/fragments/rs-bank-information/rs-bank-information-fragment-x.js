define([], () => {
  'use strict';

  class FragmentModule {
  }

  FragmentModule.prototype.sayHola = function () {

    alert('hola banks accounts') ;// + document.getElementById("ui-id-338").value );
   
    // route
    document.getElementById("oj-selectsingle-15").hint = "nuestro hint";  
    document.getElementById("oj-selectsingle-15").style.backgroundColor = "red";  
    document.getElementById("oj-selectsingle-15").ariaRequired = false; 

    document.getElementById("oj-selectsingle-11").ariaRequired = false; 
    document.getElementById("oj-selectsingle-11").style.backgroundColor = "red";  
    document.getElementById("oj-selectsingle-11").hint = "nuestro hint"; 

    
    document.getElementById("ui-id-311").ariaRequired = false;
    document.getElementById("ui-id-311").style.backgroundColor = "red"; 

     
    document.getElementById("ui-id-346").value = 'xx';

    alert('hola :'+ document.getElementById("ui-id-311").ariaLabel +  document.getElementById("oj-selectsingle-11").getAttribute('hint')    ) ;
    
    

     

  };

  return FragmentModule;
});
