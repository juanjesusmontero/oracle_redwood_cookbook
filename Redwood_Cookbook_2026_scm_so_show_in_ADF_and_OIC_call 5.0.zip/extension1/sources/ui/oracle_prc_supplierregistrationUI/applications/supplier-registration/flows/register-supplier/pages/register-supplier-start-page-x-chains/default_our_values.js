define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class default_our_values extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'oracle_prc_supplierregistrationUI:finBusinessUnitsLOV/get_finBusinessUnitsLOV',
        uriParams: {
          'finBusinessUnitsLOV_Id': $base.variables.procurementBuId,
        },
      });

      $variables.Bu_Name = response.body.BusinessUnitName;

      await $functions.default_js($variables.Bu_Name);
    }
  }

  return default_our_values;
});
