define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'demo_oic/getXX_DEMO_CALL_OIC_FROM_VB1_0',
        uriParams: {
          pHeaderId: $variables.pHeaderId,
        },
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        message: response.body.message,
        displayMode: 'persist',
        type: 'warning',
      });
    }
  }

  return WelcomePageTemplateSpPrimaryActionChain;
});
