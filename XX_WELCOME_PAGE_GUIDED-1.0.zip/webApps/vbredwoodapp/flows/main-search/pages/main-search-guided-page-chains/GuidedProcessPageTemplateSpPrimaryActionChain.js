define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class GuidedProcessPageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.varPromote.promotionDate = await $functions.currentDate();

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_Employee',
        uriParams: {
          'Employee_Id': $variables.paramEmpId,
        },
        body: $variables.varPromote,
        responseBodyFormat: 'json',
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        displayMode: 'transient',
        type: 'info',
        message: 'Employee promoted',
      });

      const toMainSearchStart = await Actions.navigateToPage(context, {
        page: 'main-search-start',
      });
    }
  }

  return GuidedProcessPageTemplateSpPrimaryActionChain;
});
