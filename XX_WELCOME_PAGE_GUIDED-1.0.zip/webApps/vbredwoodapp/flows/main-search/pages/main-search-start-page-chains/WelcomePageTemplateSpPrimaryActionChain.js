define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.varMessage = $variables.oj_table_847267151_1SelectedId;

      await Actions.callComponentMethod(context, {
        selector: '#myToast',
        method: 'open',
      });

      const toMainSearchGuided = await Actions.navigateToPage(context, {
        page: 'main-search-guided',
        params: {
          currentStep: '1',
          candidateId: $variables.oj_table_847267151_1SelectedId,
          candidateName: $variables.varRowData.firstName,
          paramEmpId: $variables.oj_table_847267151_1SelectedId,
        },
      });
    }
  }

  return WelcomePageTemplateSpPrimaryActionChain;
});
