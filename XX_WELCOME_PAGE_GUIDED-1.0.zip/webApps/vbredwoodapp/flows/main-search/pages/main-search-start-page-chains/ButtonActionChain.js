define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.varMessage = 'hola';

      await Actions.callComponentMethod(context, {
        selector: '#myToast',
        method: 'open',
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        message: '**** Info:'+$variables.oj_table_847267151_1SelectedId,
        displayMode: 'transient',
        type: 'info',
      });

      const toMainSearchGuided = await Actions.navigateToPage(context, {
        page: 'main-search-guided',
      });
    }
  }

  return ButtonActionChain;
});
