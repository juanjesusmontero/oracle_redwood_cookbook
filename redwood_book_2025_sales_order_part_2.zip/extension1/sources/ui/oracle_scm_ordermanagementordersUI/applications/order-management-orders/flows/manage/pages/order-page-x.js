define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.getHeaderId = function () {

    let a = location.href;
    let b = a.indexOf("headerId");
    let d = a.substring(b + 8);
    let c = d.indexOf("&mode");
    let e = d.substring(1, c);
    return e;
  };

  PageModule.prototype.smallAlert = function () {

    let text;
    if (confirm("Press Accept to navigate to a page with Sales Order Details") === true) {
      text = "Selected_1";
    } else {
      text = "Selected_2";
    }

    return (text);

  };

  PageModule.prototype.getBatchId = function () {
    let today = new Date();

    let mo = (today.getMonth() + 1);
    if (mo < 10) {
      mo = '0' + mo;
    }

    let da = today.getDate();
    if (da < 10) {
      da = '0' + da;
    }

    let hh = today.getHours();
    if (hh < 10) {
      hh = '0' + hh;
    }

    let mi = today.getMinutes();
    if (mi < 10) {
      mi = '0' + mi;
    }

    let ss = today.getSeconds();
    if (ss < 10) {
      ss = '0' + ss;
    }

    let date = today.getFullYear() + '_' + mo + '_' + da;
    let time = hh + '_' + mi + '_' + ss;

    return (date + '_' + time);
  };

  return PageModule;
});
