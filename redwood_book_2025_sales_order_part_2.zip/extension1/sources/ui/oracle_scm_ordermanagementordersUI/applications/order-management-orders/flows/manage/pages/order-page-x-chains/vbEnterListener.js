define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables, $functions, $chain, $modules } = context;

      const smallAlert = await $functions.smallAlert();

      if (1 === '2') {

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          message: 'Alert: selection.:'+smallAlert,
          displayMode: 'transient',
          type: 'info',
        });
      }

      const headerId = await $functions.getHeaderId();

      $variables.varHeaderId = headerId;

      if (smallAlert === 'Selected_1') {

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          message: 'Navigating to Sales order Header Id.:'+headerId,
          displayMode: 'transient',
          type: 'info',
        });

        const toMoredataforso = await Actions.navigateToApplication(context, {
          application: 'moredataforso',
          params: {
            'pHeaderId_app': $variables.varHeaderId,
          },
        });
        
      }
    }
  }

  return vbEnterListener;
});
