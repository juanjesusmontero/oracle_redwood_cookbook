/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define([], function() {
  'use strict';

  let PageModule = function PageModule() {};

  PageModule.prototype.optionRenderer1 = function(context) {    
    return context.data.UserLogin + ' | ' + context.data.FirstName   + ' | ' + context.data.LastName ;
  } ;

  PageModule.prototype.optionRenderer2 = function(context) {    
    return context.data.Service + ' | Num.Users:' + context.data.NumUsers    ;
  }  ;


  // ------------------------------------------------------------------------
  PageModule.prototype.mySplitPrivs = function (xString) {


    //var input ='Hybrid App, Phone-Gap, Apache Cordova, HTML5, JavaScript, BootStrap, JQuery, CSS3, Android Wear API'
    let output = xString.split("|");
    console.log(output);
    return output;

  };



  return PageModule;
});
