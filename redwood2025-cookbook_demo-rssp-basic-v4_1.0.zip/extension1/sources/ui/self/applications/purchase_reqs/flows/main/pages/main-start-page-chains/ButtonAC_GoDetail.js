define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonAC_GoDetail extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables } = context;

      const toMainLineDet = await Actions.navigateToPage(context, {
        page: 'main-line_det',
        params: {
          pLineId: $variables.varPO_REQ_LINE_ID,
          pPoLine: $variables.varLine,
          pPoReq: $variables.varReq,
          pReqId: $variables.varPO_REQ_iD,
        },
      });
    }
  }

  return ButtonAC_GoDetail;
});
