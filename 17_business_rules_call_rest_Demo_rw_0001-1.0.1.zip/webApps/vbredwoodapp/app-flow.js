/* Copyright (c) 2023, Oracle and/or its affiliates */

define(['fndconfig/config'], function() {
  'use strict';

  var AppModule = function AppModule() {};

  return AppModule;
});
