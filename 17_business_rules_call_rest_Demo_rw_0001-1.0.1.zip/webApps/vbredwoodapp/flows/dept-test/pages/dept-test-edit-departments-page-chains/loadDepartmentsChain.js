define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadDepartmentsChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_Departments',
        responseType: 'getDepartmentsResponse',
        uriParams: {
          'Departments_Id': $page.variables.departmentsId,
        },
      }, { id: 'loadDepartments' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedDepartments = callRestResult.body;
      $page.variables.departments = $page.variables.fetchedDepartments;
      $page.variables.departmentsETag = callRestResult.headers.get('ETag');
    }
  }

  return loadDepartmentsChain;
});
