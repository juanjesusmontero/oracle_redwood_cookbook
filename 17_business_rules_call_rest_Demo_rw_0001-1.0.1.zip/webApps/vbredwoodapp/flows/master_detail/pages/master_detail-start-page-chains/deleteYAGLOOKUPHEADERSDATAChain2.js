define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteYAGLOOKUPHEADERSDATAChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.yAGLOOKUPHEADERSDATAId 
     */
    async run(context, { yAGLOOKUPHEADERSDATAId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toMasterDetailDetail2 = await Actions.navigateToPage(context, {
        page: 'master_detail-detail2',
        params: {
          'p_head_id': yAGLOOKUPHEADERSDATAId,
        },
      });
    }
  }

  return deleteYAGLOOKUPHEADERSDATAChain2;
});
