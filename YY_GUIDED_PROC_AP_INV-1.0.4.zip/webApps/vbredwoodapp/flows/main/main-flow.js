/* Copyright (c) 2023, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  var FlowModule = function FlowModule() {};

  return FlowModule;
});
