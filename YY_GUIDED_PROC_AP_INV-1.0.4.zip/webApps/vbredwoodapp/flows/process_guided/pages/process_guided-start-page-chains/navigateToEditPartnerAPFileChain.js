define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditPartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageProcessGuidedEditPartnerApfileResult = await Actions.navigateToPage(context, {
        page: 'process_guided-edit-partner-apfile',
        params: {
          partnerAPFileId: partnerAPFileId,
        },
      });
    }
  }

  return navigateToEditPartnerAPFileChain;
});
