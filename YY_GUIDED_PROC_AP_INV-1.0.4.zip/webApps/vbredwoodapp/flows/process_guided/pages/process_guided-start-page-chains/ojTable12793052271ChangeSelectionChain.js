define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable12793052271ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1279305227_1SelectedId = partnerAPFileId;
    }
  }

  return ojTable12793052271ChangeSelectionChain;
});
