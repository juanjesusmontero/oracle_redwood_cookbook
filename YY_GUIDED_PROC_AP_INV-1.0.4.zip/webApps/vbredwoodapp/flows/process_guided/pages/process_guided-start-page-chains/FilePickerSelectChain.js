define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.detail 
     */
    async run(context, { detail }) {
      const { $page, $flow, $application } = context;

      $page.variables.Filelist.name = detail[0].name;

      const callFunctionResult = await $page.functions.processFilePapa(detail[0]);

      const callFunctionCreateColumnsArray = await $page.functions.createColumnsArray(callFunctionResult);

      $page.variables.columns = callFunctionCreateColumnsArray;

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.MyADPWithExcelData,
        add: {
          data: callFunctionResult,
        },
      });

      const callChainGenerateBatchIdResult = await Actions.callChain(context, {
        id: 'generateBatch_Id',
      });
    }
  }

  return FilePickerSelectChain;
});
