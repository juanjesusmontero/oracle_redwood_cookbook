define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class savePartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.savePartnerAPFileChainInProgress = true;

      // Validates PartnerAP_File form
      const validateFormResult = await Actions.callChain(context, {
        chain: 'flow:validateFormChain',
        params: {
          validationGroupId: 'validation-group',
        },
      });

      if (validateFormResult === true) {
        const callRestSavePartnerAPFileResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_PartnerAP_File',
          body: $page.variables.partnerAPFile,
          uriParams: {
            'PartnerAP__File_Id': $page.variables.partnerAPFileId,
          },
        }, { id: 'savePartnerAPFile' });

        if (callRestSavePartnerAPFileResult.ok) {
          $page.variables.partnerAPFile = callRestSavePartnerAPFileResult.body;
          $page.variables.partnerAPFileETag = callRestSavePartnerAPFileResult.headers.get('ETag');

          await Actions.fireNotificationEvent(context, {
            summary: 'PartnerAP_File saved',
            message: 'PartnerAP_File record successfully updated',
            displayMode: 'transient',
            type: 'confirmation',
          }, { id: 'fireSuccessNotification' });

          await Actions.navigateBack(context, {
          }, { id: 'navigateBack' });
        } else {
          // Create error message
          const errorMessage = callRestSavePartnerAPFileResult.body?.['o:errorDetails']?.[0]?.detail ||
                               `Could not update PartnerAP_File: status ${callRestSavePartnerAPFileResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
            displayMode: 'transient',
          }, { id: 'fireErrorNotification' });
        }
      }

      // Sets the progress variable to false
      $page.variables.savePartnerAPFileChainInProgress = false;
    }
  }

  return savePartnerAPFileChain;
});
