/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class fetchItemChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {any} params.configuration
     * @param {number} params.limit
     * @param {number} params.offset
     */
    async run(context, { limit, offset }) {
      const { $page } = context;

      const fetchResult = await Actions.callRest(context, {
        // Specify below the endpoint for next and previous items
        endpoint: null,
        uriParams: {
          limit: limit,
          offset: offset
        },
        //hookHandler: configuration.hookHandler
      });
      
      if (fetchResult.ok) {
        $page.variables.nextItem = { 'label': 'Update nextItem label based on fetched results'};
        $page.variables.previousItem = {'label': 'Update previousItem label based on fetched results'};
        $page.variables.itemId = { 'label': 'Update itemId based on fetched results key value' };
      }

      return fetchResult;
    }
  }

  return fetchItemChain;
});
