define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToPR_LinesDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.purchaseRequisitionsLinesId
     */
    async run(context, { purchaseRequisitionsLinesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const toMainLineDet = await Actions.navigateToPage(context, {
        page: 'main-line_det',
        params: {
          pLineId: $variables.varPO_REQ_LINE_ID,
          pReqId: $variables.varPO_REQ_iD,
          poLine: $variables.varLine,
          poReq: $variables.varReq,
        },
      });

      if (1 === '2') {

        const navigateToPageMainPR_LinesDetailResult = await Actions.navigateToPage(context, {
          page: 'main-pr-lines-detail',
          params: {
            purchaseRequisitionsLinesId: purchaseRequisitionsLinesId,
            poReqId: $variables.varPO_REQ_iD,
          },
        });
      }
    }
  }

  return navigateToPR_LinesDetailChain;
});
