define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AssignMessage extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{summary:string,message:string,displayMode:string,type:string,key:string,target:string}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.messageADP.data',
        ],
      });

      $page.variables.currMessage.id = event.key;

      $page.variables.currMessage.detail = event.message;

      $page.variables.currMessage.summary = event.summary;

      $page.variables.currMessage.severity = event.type;

      $page.variables.currMessage.displayMode = event.displayMode;

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.messageADP,
        add: {
          data: $page.variables.currMessage,
        },
      });
    }
  }

  return AssignMessage;
});
