define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadPartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestGetPartnerAPFileResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_PartnerAP_File',
        responseType: 'getPartnerAPFileResponse',
        uriParams: {
          'PartnerAP__File_Id': $page.variables.partnerAPFileId,
        },
      }, { id: 'loadPartnerAPFile' });

      if (callRestGetPartnerAPFileResult.ok) {
        $page.variables.partnerAPFile = callRestGetPartnerAPFileResult.body;
        $page.variables.partnerAPFileETag = callRestGetPartnerAPFileResult.headers.get('ETag');
      } else {
        // Create error message
        const errorMessage = callRestGetPartnerAPFileResult.body?.['o:errorDetails']?.[0]?.detail ||
                             `Could not load data: status ${callRestGetPartnerAPFileResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });
      }
    }
  }

  return loadPartnerAPFileChain;
});
