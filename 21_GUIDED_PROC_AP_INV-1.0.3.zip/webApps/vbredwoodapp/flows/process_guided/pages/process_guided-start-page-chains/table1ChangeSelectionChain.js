define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class table1ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application } = context;
      $page.variables.table1SelectedId = partnerAPFileId;
    }
  }

  return table1ChangeSelectionChain;
});
