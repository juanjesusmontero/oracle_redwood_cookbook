define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AC_LoadData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.xCounterOk = 0;
      $page.variables.xCounterError = 0;

      const forEachResult = await ActionUtils.forEach($page.variables.MyADPWithExcelData.data, async (current_1, index) => {

        $page.variables.var_file_line_read = current_1;

        $page.variables.create_PartnerAP_File.batchId = $page.variables.xBatchId;

        $page.variables.create_PartnerAP_File.vendorName = $page.variables.var_file_line_read.Vendor_Name;

        $page.variables.create_PartnerAP_File.vendorNumber = $page.variables.var_file_line_read['Vendor Number'];

        $page.variables.create_PartnerAP_File.vendorAddressCode = $page.variables.var_file_line_read.Vendor_Address_Code;

        try {
          $page.variables.create_PartnerAP_File.netAmount = $page.variables.var_file_line_read['Net Amount'];
        } catch (error1) {
          console.log('*** net_amt');
        }

        $page.variables.create_PartnerAP_File.distributionSet = $page.variables.var_file_line_read['Distribution Set'];

        $page.variables.create_PartnerAP_File.invoiceDescription = $page.variables.var_file_line_read['Invoice Description'];

        $page.variables.create_PartnerAP_File.invoiceDate = $page.variables.var_file_line_read.Invoice_Date;

        $page.variables.create_PartnerAP_File.fileName = $page.variables.Filelist.name;

        $page.variables.create_PartnerAP_File.userLoad = $application.user.username;

        $page.variables.create_PartnerAP_File.status = 'NEW';

        try {
          const CreatePartnerAPFileResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_PartnerAP_File',
            body: $page.variables.create_PartnerAP_File,
            responseBodyFormat: 'json',
          });

          if (CreatePartnerAPFileResult.ok) {
            console.log('### call_rest1 OK');
            $page.variables.xCounterOk = $page.variables.xCounterOk+1;            
          }
          else{
            console.log('### call_rest2 ERROR');
            $page.variables.xCounterError = $page.variables.xCounterError+1;
          }
        } catch (error2) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Info.',
            message: 'Error calling REST',
            displayMode: 'transient',
            type: 'info',
          }, { id: 'fn11' });
        }
      }, { mode: 'serial' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Info.',
        message: 'Inserted:' + $page.variables.xCounterOk + ' records. Errored:'+$page.variables.xCounterError,
        displayMode: 'transient',
        type: 'info',
      }, { id: 'fn1' });
    }
  }

  return AC_LoadData;
});
