define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.partnerAPFileListSDP,
        refresh: null,
      });

      const callComponentMethodTable1RefreshResult = await Actions.callComponentMethod(context, {
        selector: '#table1',
        method: 'refresh',
      });
    }
  }

  return ButtonActionChain;
});
