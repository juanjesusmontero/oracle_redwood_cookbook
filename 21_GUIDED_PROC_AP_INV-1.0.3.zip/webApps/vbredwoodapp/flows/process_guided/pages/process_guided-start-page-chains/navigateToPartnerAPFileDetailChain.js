define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToPartnerAPFileDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageProcessGuidedPartnerApfileDetailResult = await Actions.navigateToPage(context, {
        page: '/shell/review/review-partner-apfile-detail',
        params: {
          itemId: partnerAPFileId,
          parentPage: $flow.currentPage,
        },
      });
    }
  }

  return navigateToPartnerAPFileDetailChain;
});
