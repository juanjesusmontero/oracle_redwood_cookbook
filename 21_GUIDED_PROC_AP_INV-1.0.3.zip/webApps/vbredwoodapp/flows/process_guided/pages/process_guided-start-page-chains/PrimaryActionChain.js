define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.xReqProcess.pBatchId = $application.variables.xBatchIdGlobal;

      // runMainRest
      const resultProcess = await Actions.callRest(context, {
        endpoint: 'conn_demo/postXX_AP_INVOIC_REST_VB1_0DataPartnerAP_File',
        responseBodyFormat: 'json',
        responseType: 'respProcessType',
        body: $page.variables.xReqProcess,
      }, { id: 'runMainRest' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Selected',
        message: 'Status:' + resultProcess.body.Status + ' ; ' + resultProcess.body.StatusMessage,
        displayMode: 'transient',
        type: 'info',
      }, { id: 'fn6' });
    }
  }

  return PrimaryActionChain;
});
