define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadPartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestGetPartnerAPFileResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_PartnerAP_File',
        responseType: 'getPartnerAPFileResponse',
        uriParams: {
          'PartnerAP__File_Id': $page.variables.partnerAPFileId,
        },
      }, { id: 'loadPartnerAPFile' });

      if (callRestGetPartnerAPFileResult.ok) {
        $page.variables.partnerAPFile = callRestGetPartnerAPFileResult.body;
      } else {
        await Actions.fireNotificationEvent(context, {
          message: 'Could not load data: status ' + callRestGetPartnerAPFileResult.status,
          displayMode: 'persist',
          type: 'error',
          summary: 'Could not load data',
        }, { id: 'fireErrorNotification' });
      }
    }
  }

  return loadPartnerAPFileChain;
});
