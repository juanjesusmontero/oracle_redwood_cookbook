define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadPartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId 
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      if (true && partnerAPFileId !== undefined) {
        // Clears PartnerAP_File data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.partnerAPFile',
          ],
        }, { id: 'resetPartnerAPFileData' });

        // Initiates REST call loading PartnerAP_File data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_PartnerAP_File',
          responseType: 'getPartnerAPFileResponse',
          uriParams: {
            'PartnerAP__File_Id': partnerAPFileId,
          },
        }, { id: 'loadPartnerAPFile' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the PartnerAP_File variable
        $page.variables.partnerAPFile = callRestResult.body;
      }
    }
  }

  return loadPartnerAPFileChain;
});
