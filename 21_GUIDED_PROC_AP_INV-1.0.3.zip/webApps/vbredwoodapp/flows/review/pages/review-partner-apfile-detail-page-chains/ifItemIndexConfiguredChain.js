/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class ifItemIndexConfiguredChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;
      
      // Check to see if item index is provided
      if ($page.variables.itemIndex >= 0) {
        // Fetch item
        await Actions.callChain(context, {
          chain: 'fetchItemChain',
          params: {
            limit: $page.variables.itemIndex ? 3 : 2,
            offset: $page.variables.itemIndex ? ($page.variables.itemIndex - 1) : 0,
          }
        });
      }
    }
  }

  return ifItemIndexConfiguredChain;
});
