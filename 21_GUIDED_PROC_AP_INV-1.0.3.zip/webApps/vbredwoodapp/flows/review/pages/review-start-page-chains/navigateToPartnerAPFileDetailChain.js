define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToPartnerAPFileDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application, $variables } = context;
      const navigateToPageReviewPartnerApfileDetailResult = await Actions.navigateToPage(context, {
        page: 'review-partner-apfile-detail',
        params: {
          partnerAPFileId: partnerAPFileId,
          itemId: $variables.oj_table_1927023115_1SelectedId,
          parentPage: $flow.currentPage,
        },
      });
    }
  }

  return navigateToPartnerAPFileDetailChain;
});
