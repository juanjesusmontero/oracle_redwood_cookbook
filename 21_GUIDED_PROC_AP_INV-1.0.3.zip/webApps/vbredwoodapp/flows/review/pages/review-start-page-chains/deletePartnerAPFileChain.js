define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deletePartnerAPFileChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.partnerAPFileId 
     */
    async run(context, { partnerAPFileId }) {
      const { $page, $flow, $application } = context;

      const callRestDeletePartnerAPFileResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_PartnerAP_File',
        uriParams: {
          'PartnerAP__File_Id': partnerAPFileId,
        },
      }, { id: 'deletePartnerAPFile' });

      if (callRestDeletePartnerAPFileResult.ok) {
        // Resets selection variable
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.oj_table_1927023115_1SelectedId',
          ],
        }, { id: 'resetSelection' });

        await Actions.fireDataProviderEvent(context, {
          target: $page.variables.partnerAPFileListSDP,
          refresh: null,
        }, { id: 'refreshDataProvider' });

        await Actions.fireNotificationEvent(context, {
          summary: 'PartnerAP_File deleted',
          message: `PartnerAP_File [${partnerAPFileId}] successfully deleted`,
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestDeletePartnerAPFileResult.status}`,
          displayMode: 'transient',
          type: 'error',
        }, { id: 'fireErrorNotification' });
      }
    }
  }

  return deletePartnerAPFileChain;
});
