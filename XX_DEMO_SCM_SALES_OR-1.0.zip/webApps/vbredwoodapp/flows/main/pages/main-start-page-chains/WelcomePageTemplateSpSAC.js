define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpSAC extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.actionId 
     */
    async run(context, { actionId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (actionId === 'Lines') {
        const toMainLines = await Actions.navigateToPage(context, {
          page: 'main-lines',
          params: {
            pHeaderId: $variables.varHeaderId,
            pOrderNumber: $variables.varOrderNumber,
            pOrderKey: $variables.varOrderKey,
          },
        });
      }
    }
  }

  return WelcomePageTemplateSpSAC;
});
