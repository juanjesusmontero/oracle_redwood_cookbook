define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpSAC extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.actionId 
     */
    async run(context, { actionId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (actionId === 'billToCustomer') {
        const toBillToCustomers = await Actions.navigateToPage(context, {
          page: 'bill-to-customers',
          params: {
            pOrder: $variables.pOrderKey,
            pHash: $application.variables.varLineHashGlobal,
            pLineNumber: $variables.varLineNumber,
          },
        });
      }
    }
  }

  return WelcomePageTemplateSpSAC;
});
