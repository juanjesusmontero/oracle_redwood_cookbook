define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getHash_01 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.pOrder 
     * @param {string} params.pLine 
     */
    async run(context, { pOrder, pLine }) {
      const { $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'sn_get_hash/getXX_GET_SO_HASH_LINE1_0',
        uriParams: {
          pOrderKey: pOrder,
          pLineId: pLine,
        },
      });

      $variables.varLineHashGlobal = response.body.HashCode;

      if (1 === '2') {

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          message: response.body.HashCode+' '+ response.body.CompleteURL,
          displayMode: 'transient',
          type: 'info',
        });
      }
    }
  }

  return getHash_01;
});
