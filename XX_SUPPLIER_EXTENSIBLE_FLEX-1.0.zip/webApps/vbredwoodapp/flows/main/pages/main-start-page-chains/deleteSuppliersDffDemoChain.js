define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteSuppliersDffDemoChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suppliersDffDemoId 
     */
    async run(context, { suppliersDffDemoId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_SuppliersDffDemo',
        uriParams: {
          'SuppliersDffDemo_Id': suppliersDffDemoId,
        },
      }, { id: 'deleteSuppliersDffDemo' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1896815765_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.suppliersDffDemoListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'SuppliersDffDemo deleted',
        message: `SuppliersDffDemo [${suppliersDffDemoId}] successfully deleted`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteSuppliersDffDemoChain;
});
