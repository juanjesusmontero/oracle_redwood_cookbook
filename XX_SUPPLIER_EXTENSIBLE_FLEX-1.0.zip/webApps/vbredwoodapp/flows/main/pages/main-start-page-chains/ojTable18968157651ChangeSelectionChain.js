define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable18968157651ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suppliersDffDemoId
     */
    async run(context, { suppliersDffDemoId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_1896815765_1SelectedId = suppliersDffDemoId;
    }
  }

  return ojTable18968157651ChangeSelectionChain;
});
