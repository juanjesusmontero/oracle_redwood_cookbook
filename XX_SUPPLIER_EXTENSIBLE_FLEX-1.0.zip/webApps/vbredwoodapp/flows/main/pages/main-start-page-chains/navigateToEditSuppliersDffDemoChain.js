define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditSuppliersDffDemoChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suppliersDffDemoId
     */
    async run(context, { suppliersDffDemoId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditSuppliersDffDemoResult = await Actions.navigateToPage(context, {
        page: 'main-edit-suppliers-dff-demo',
        params: {
          suppliersDffDemoId: suppliersDffDemoId,
        },
      });
    }
  }

  return navigateToEditSuppliersDffDemoChain;
});
