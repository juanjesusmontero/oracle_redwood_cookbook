define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadSuppliersDffDemoChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_SuppliersDffDemo',
        responseType: 'getSuppliersDffDemoResponse',
        uriParams: {
          'SuppliersDffDemo_Id': $page.variables.suppliersDffDemoId,
        },
      }, { id: 'loadSuppliersDffDemo' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedSuppliersDffDemo = callRestResult.body;
      $page.variables.suppliersDffDemo = $page.variables.fetchedSuppliersDffDemo;
      $page.variables.suppliersDffDemoETag = callRestResult.headers.get('ETag');
    }
  }

  return loadSuppliersDffDemoChain;
});
