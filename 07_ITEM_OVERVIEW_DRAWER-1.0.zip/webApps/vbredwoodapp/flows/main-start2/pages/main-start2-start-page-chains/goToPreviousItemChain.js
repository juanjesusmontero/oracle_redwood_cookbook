/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain'
], ActionChain => {
  'use strict';

  class goToPreviousItemChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      // Go to the previous item
      $page.variables.itemIndex = $page.variables.itemIndex ? ($page.variables.itemIndex - 1) : 0;
    }
  }

  return goToPreviousItemChain;
});
