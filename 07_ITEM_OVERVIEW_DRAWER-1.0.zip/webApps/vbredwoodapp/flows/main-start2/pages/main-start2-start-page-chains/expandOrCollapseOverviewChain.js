/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class expandOrCollapseOverviewChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {boolean} params.expand
     */
    async run(context, { expand }) {
      const { $page, $application } = context;

      // Expand or collapse overview to full page display
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          itemId: $page.variables.itemId,
          itemIndex: $page.variables.itemIndex,
          parentPage: $page.variables.parentPage,
          overviewExpanded: expand,
          inFlowBack: $page.variables.inFlowBack,
          bidirectionalNavigation: $page.variables.bidirectionalNavigation
        },
        history: 'skip'
      });
    }
  }

  return expandOrCollapseOverviewChain;
});
