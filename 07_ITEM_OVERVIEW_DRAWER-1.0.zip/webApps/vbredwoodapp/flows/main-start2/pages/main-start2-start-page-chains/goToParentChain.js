/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class goToPageChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {string} params.parentPage
     */
    async run(context, { parentPage }) {
      const { $page } = context;

      // Navigate to a page
      await Actions.navigateToPage(context, {
        page: parentPage,
        params: $page.variables.parentUrlParams
      });
    }
  }

  return goToPageChain;
});
