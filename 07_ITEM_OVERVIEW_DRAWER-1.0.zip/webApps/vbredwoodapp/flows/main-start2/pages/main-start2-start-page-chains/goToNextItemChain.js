/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain'
], ActionChain => {
  'use strict';

  class goToNextItemChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      // Go to the next item
      $page.variables.itemIndex = $page.variables.itemIndex ? ($page.variables.itemIndex + 1) : 1;
    }
  }

  return goToNextItemChain;
});
