define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadCandidatesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.candidatesId 
     */
    async run(context, { candidatesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      if (true && candidatesId !== undefined) {
        // Clears Candidates data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.candidates',
          ],
        }, { id: 'resetCandidatesData' });

        // Initiates REST call loading Candidates data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_Candidates',
          responseType: 'getCandidatesResponse',
          uriParams: {
            'Candidates_Id': candidatesId,
          },
        }, { id: 'loadCandidates' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the Candidates variable
        $page.variables.candidates = callRestResult.body;
      }
    }
  }

  return loadCandidatesChain;
});
