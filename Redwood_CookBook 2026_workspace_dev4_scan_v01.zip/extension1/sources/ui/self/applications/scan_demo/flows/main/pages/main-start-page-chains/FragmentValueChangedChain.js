define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FragmentValueChangedChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.value 
     * @param {string} params.method 
     * @param {any} params.listKey 
     * @param {any} params.listData 
     * @param {any} params.listMetadata 
     * @param {object[]} params.allValues 
     * @param {boolean} params.validDate 
     */
    async run(context, { value, method, listKey, listData, listMetadata, allValues, validDate }) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables } = context;

      if (1 === '2') {
        $variables.varEAN_Read = value;
      }

      $variables.varQuery = "ItemDFF.ean13="+"'"+  $variables.varEAN_Read  + "'" + " AND OrganizationCode="+ "'"+$variables.varMasterOrgCode+"'";

      if (1 === '2') {

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          type: 'info',
          displayMode: 'transient',
          message: $variables.varEAN_Read + '---' + $variables.varQuery,
        });
      }

      const response = await Actions.callRest(context, {
        endpoint: 'site_scan_demo:sn_items/getall_itemsV2',
        responseBodyFormat: 'json',
        uriParams: {
          q: $variables.varQuery,
          onlyData: true,
          limit: '1',
        },
      }, { id: 'rest1' });

      $variables.varCount = response.body.count;

      if ($variables.varCount === 1) {

        const results = await ActionUtils.forEach(response.body.items, async (item, index) => {

          $variables.varItemId = item.ItemId;
          $variables.varItemDescription = item.ItemDescription;
          $variables.varItemNumber = item.ItemNumber;
        }, { mode: 'serial' });
      }
      else{
        

        await Actions.fireNotificationEvent(context, {
          summary: 'Info',
          message: 'EAN not found in Master Inventory Org. Count:'+response.body.count,
          displayMode: 'transient',
          type: 'info',
        });
      }
    }
  }

  return FragmentValueChangedChain;
});
