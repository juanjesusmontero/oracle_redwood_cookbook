define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadPurchaseRequisitionsLinesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.purchaseRequisitionsId 
     * @param {string} params.purchaseRequisitionsLinesId 
     */
    async run(context, { purchaseRequisitionsId, purchaseRequisitionsLinesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      if (true && purchaseRequisitionsId !== undefined && purchaseRequisitionsLinesId !== undefined) {
        // Clears purchaseRequisitions/lines data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.purchaseRequisitionsLines',
          ],
        }, { id: 'resetPurchaseRequisitionsLinesData' });

        // Initiates REST call loading purchaseRequisitions/lines data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_pr_01/get_purchaseRequisitions-lines',
          responseType: 'getPurchaseRequisitionsLinesResponse',
          uriParams: {
            'purchaseRequisitions_Id': purchaseRequisitionsId,
            'purchaseRequisitions_lines_Id': purchaseRequisitionsLinesId,
          },
        }, { id: 'loadPurchaseRequisitionsLines' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data 1',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the purchaseRequisitions/lines variable
        $page.variables.purchaseRequisitionsLines = callRestResult.body;
      }
    }
  }

  return loadPurchaseRequisitionsLinesChain;
});
