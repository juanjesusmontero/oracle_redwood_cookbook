define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables } = context;

      await Actions.fireNotificationEvent(context, {
        summary: 'info',
        message: 'Some dff data updated press f5 to see changes',
        displayMode: 'transient',
        type: 'info',
      });

      $variables.varPost.demoRedwood = 'demo 1.:'+$base.flow.variables.activeRequisitionDetails.RequisitionHeaderId;
      $variables.varPost.demoRedwood2 = 'demo 2.:'+ $base.flow.variables.activeRequisitionDetails.RequisitionNumber;
      $variables.varPost.RequisitionHeaderId = $base.flow.variables.activeRequisitionDetails.RequisitionHeaderId;

      const response = await Actions.callRest(context, {
        endpoint: 'site_prc_extension:sn_pr/create_purchaseRequisitions-DFF',
        uriParams: {
          'purchaseRequisitions_Id': $base.flow.variables.activeRequisitionDetails.RequisitionHeaderId,
        },
        body: $variables.varPost,
        responseBodyFormat: 'json',
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'site_prc_extension:sn_pr/get_purchaseRequisitions',
        uriParams: {
          'purchaseRequisitions_Id': $base.flow.variables.activeRequisitionDetails.RequisitionHeaderId,
        },
        responseBodyFormat: 'json',
        responseType: 'get_purchaseRequisitions',
      });

      $variables.varBuName = response2.body.RequisitioningBU;

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        message: $variables.varBuName,
        displayMode: 'persist',
        type: 'info',
      });
    }
  }

  return vbEnterListener;
});
