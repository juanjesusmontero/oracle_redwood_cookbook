define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class demoUpdateDefaults extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $layout, $base, $extension, $responsive, $user, $constants, $variables, $functions } = context;


      const varPoHeaderId = await $functions.getPoHeaderId();

      $variables.var_update_draftPurchaseOrders.Description = 'From extension 91xxx';

      const response2 = await Actions.callRest(context, {
        endpoint: 'site_prc_extension:draft_pos/update_draftPurchaseOrders',
        body: $variables.var_update_draftPurchaseOrders,
        uriParams: {
          'draftPurchaseOrders_Id': varPoHeaderId,
        },
        responseBodyFormat: 'json',
      });




    }
  }

  return demoUpdateDefaults;
});
