define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.default_js = function (pBu_Name) {

    alert('Hi from VB_REDWOOD_COOKBOOK_2026');

    // These lines are just to play, and see what we can acomplish with JavaScript
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").style = "background-color:green";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").style = "color:#00446B;font-weight: bold;";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").style.backgroundColor = "green";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").style.color = "red";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").required = true;
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").placeholder = "Your text , please.";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").hint = "Our hint";
    document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").focus();


    // For demo purposes. Adapt to your needs
    // See DISCLAIMER
    if (pBu_Name === 'US1 Business Unit') {
      document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").value = "Demo from JavaScript:" + pBu_Name;
      document.getElementById("companyDetailsID_fl_manageCompanyDetails.CorporateWebsite").value = "www.oracle.com";
      document.getElementById("busRelSelectSingle").value = "SPEND_AUTHORIZED";
      //document.getElementById("taxOrganizationType").value = "INDIVIDUAL";
    }
    else {
      document.getElementById("companyDetailsID_fl_manageCompanyDetails.Justification").value = "Demo from JavaScript:" + pBu_Name;
      document.getElementById("companyDetailsID_fl_manageCompanyDetails.CorporateWebsite").value = "www.sap.com";
      document.getElementById("busRelSelectSingle").value = "PROSPECTIVE";
      //document.getElementById("taxOrganizationType").value = "CORPORATION";

    }

  };


  PageModule.prototype.default_js_by_country = function (pCountryCode) {

    alert('Hi from VB_REDWOOD_COOKBOOK_2026:'+pCountryCode);

    // For demo purposes. Adapt to your needs
    // See DISCLAIMER
    if (pCountryCode === 'US') {
      document.getElementById("taxOrganizationType").value = "INDIVIDUAL";
    }

    if (pCountryCode === 'AE') { 
      document.getElementById("taxOrganizationType").value = "BASKET";
    }

    if (pCountryCode === 'AL') { 
      document.getElementById("taxOrganizationType").value = "CORPORATION";
    }    

    if (pCountryCode === 'DZ') { 
      document.getElementById("taxOrganizationType").value = "FOREIGN INVESTOR";
    } 


  };  

  return PageModule;

});

