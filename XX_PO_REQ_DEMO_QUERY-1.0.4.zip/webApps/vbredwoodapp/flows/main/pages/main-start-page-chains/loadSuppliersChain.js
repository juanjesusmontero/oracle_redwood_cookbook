define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadSuppliersChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suppliersId 
     */
    async run(context, { suppliersId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      if (true && suppliersId !== undefined) {
        // Clears suppliers data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.suppliers',
          ],
        }, { id: 'resetSuppliersData' });

        // Initiates REST call loading suppliers data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_supp_01/get_suppliers',
          responseType: 'getSuppliersResponse',
          uriParams: {
            'suppliers_Id': suppliersId,
          },
        }, { id: 'loadSuppliers' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the suppliers variable
        $page.variables.suppliers = callRestResult.body;
      }
    }
  }

  return loadSuppliersChain;
});
