define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables, $functions, $chain, $modules } = context;

      const smallAlert = await $functions.smallAlert();

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        message: 'Alert: selection.:'+smallAlert,
        displayMode: 'transient',
        type: 'info',
      });

      const headerId = await $functions.getHeaderId();

      $variables.varHeaderId = headerId;

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        message: 'Sales order Header Id.:'+headerId,
        displayMode: 'transient',
        type: 'info',
      });
    }
  }

  return vbEnterListener;
});
