define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createPostSuppliersChain extends ActionChain {

    /**
     * Saves changes and creates new postSuppliers record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createPostSuppliersChainInProgress = true;

      try {
        // Validates postSuppliers form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'postSuppliers-validation-group-2058348651-1',
          },
        }, { id: 'validatePostSuppliers' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new postSuppliers record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'demo_upload_supplier/postSuppliers',
          body: $page.variables.postSuppliers,
        }, { id: 'savePostSuppliers' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = `Could not create new postSuppliers: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'postSuppliers saved',
          message: 'postSuppliers record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets postSuppliers variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.postSuppliers',
          ],
        }, { id: 'resetPostSuppliers' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createPostSuppliersChainInProgress = false;
      }
    }
  }

  return createPostSuppliersChain;
});
