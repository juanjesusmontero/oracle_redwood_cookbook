/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain'
], ActionChain => {
  'use strict';

  class previousChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      $page.variables.rowIndex = $page.variables.rowIndex ? ($page.variables.rowIndex - 1) : 0;
    }
  }

  return previousChain;
});
