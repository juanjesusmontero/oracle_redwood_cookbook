/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class goToParentChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {string} params.parentPage
     */
    async run(context, { parentPage }) {
      await Actions.navigateToPage(context, {
        page: parentPage,
      });
    }
  }

  return goToParentChain;
});
