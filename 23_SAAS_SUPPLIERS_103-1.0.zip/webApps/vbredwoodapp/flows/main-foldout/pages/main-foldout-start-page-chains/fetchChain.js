/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class fetchChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {any} params.configuration
     * @param {number} params.limit
     * @param {number} params.offset
     */
    async run(context, { configuration, limit, offset }) {
      const { $page } = context;

      //Load publicWorkers record
      const processResults = await Actions.callRest(context, {
        endpoint: "",
        uriParams: {
          limit: limit,
          offset: offset
        },
        hookHandler: configuration.hookHandler
      });

      if (processResults.ok) {
        $page.variables.nextStep = { label: 'Update nextStep variable based on fetched results' };
        $page.variables.previousStep = { label: 'Update previousStep variable based on fetched results' };
      }

      return processResults;
    }
  }

  return fetchChain;
});
