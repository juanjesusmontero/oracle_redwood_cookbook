/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class FlowModule {
  }

  return FlowModule;
});
