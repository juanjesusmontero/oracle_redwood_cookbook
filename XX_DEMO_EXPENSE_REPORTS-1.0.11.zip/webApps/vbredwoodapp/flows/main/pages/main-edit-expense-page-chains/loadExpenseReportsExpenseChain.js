define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadExpenseReportsExpenseChain extends ActionChain {

    /**
     * Loads expenseReports/Expense record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.expenseReportsExpenseId 
     * @param {string} params.expenseReportsId 
     */
    async run(context, { expenseReportsExpenseId, expenseReportsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Loading.
      $page.variables.expenseReportsExpenseEditFormStatus = 'loading';

      try {
        // Tests the REST call can be initiated
        if (true && expenseReportsExpenseId !== undefined && expenseReportsId !== undefined) {
          // Initiates REST call loading expenseReports/Expense data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'sn_expenseReports/get_expenseReports-Expense',
            responseType: 'getExpenseReportsExpenseResponse',
            uriParams: {
              'expenseReports_Expense_Id': expenseReportsExpenseId,
              'expenseReports_Id': expenseReportsId,
            },
          }, { id: 'loadExpenseReportsExpense' });

          if (!callRestResult.ok) {
            // Shows an error message informing about data load failure
            await Actions.fireNotificationEvent(context, {
              summary: 'Could not load data',
              message: 'Could not load data: status ' + callRestResult.status,
              displayMode: 'persist',
              type: 'error',
            }, { id: 'fireErrorNotification' });

            return;
          }

          // Assigns data loaded by the REST call to the expenseReports/Expense variable
          $page.variables.fetchedExpenseReportsExpense = callRestResult.body;

          // Assigns data loaded by the REST call to the expenseReports/Expense variable
          $page.variables.expenseReportsExpenseETag = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the expenseReports/Expense editable record variable
          $page.variables.expenseReportsExpense = $page.variables.fetchedExpenseReportsExpense;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.expenseReportsExpenseEditFormStatus = 'ready';
      }
    }
  }

  return loadExpenseReportsExpenseChain;
});
