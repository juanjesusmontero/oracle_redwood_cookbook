/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     */
    async run(context) {
      const { $page, $variables } = context;
      await Actions.callChain(context, {
        chain: 'saveExpenseReportsExpenseChain',
        params: {
          expenseReportsId: $variables.varExpenseReportId,
          expenseReportsExpenseId: $variables.varExpenseId,
        },
      });

      // Reset dirty data
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.dirtyDataFlag',
        ],
      });

      $page.variables.isSaved = true;

      /*
      if ($page.variables.formState === 'valid') {
      } else {
        await Actions.callComponentMethod(context, {
          selector: 'oj-dynamic-form',
          method: 'showMessages',
        });        
      }
      */

    }
  }

  return spSaveChain;
});
