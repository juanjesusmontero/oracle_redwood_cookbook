define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveExpenseReportsExpenseChain extends ActionChain {

    /**
     * Saves expenseReports/Expense record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.expenseReportsExpenseId 
     * @param {string} params.expenseReportsId 
     */
    async run(context, { expenseReportsExpenseId, expenseReportsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Saving.
      $page.variables.expenseReportsExpenseEditFormStatus = 'saving';

      try {
        // Validates expenseReports/Expense form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'expenseReportsExpense-validation-group-1847728774-1',
          },
        }, { id: 'validateExpenseReportsExpense' });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.expenseReportsExpense,
          fetchedRecord: $page.variables.fetchedExpenseReportsExpense,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        // Initiates REST call saving expenseReports/Expense data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_expenseReports/update_expenseReports-Expense',
          body: payload,
          headers: $page.variables.expenseReportsExpenseETag ? { 'If-Match': $page.variables.expenseReportsExpenseETag } : null,
          requestType: 'json',
          uriParams: {
            'expenseReports_Expense_Id': expenseReportsExpenseId,
            'expenseReports_Id': expenseReportsId,
          },
        }, { id: 'saveExpenseReportsExpense' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not edit expenseReports/Expense: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'expenseReports/Expense saved',
          message: 'expenseReports/Expense record successfully updated',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Calls action chain re-loading expenseReports/Expense data
        await Actions.callChain(context, {
          chain: 'loadExpenseReportsExpenseChain',
          params: {
            expenseReportsExpenseId: $page.variables.varExpenseId,
            expenseReportsId: $page.variables.varExpenseReportId,
          },
        }, { id: 'callLoadExpenseReportsExpenseChain' });
      } finally {
        // Updates form status to Ready.
        $page.variables.expenseReportsExpenseEditFormStatus = 'ready';
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveExpenseReportsExpenseChain;
});
