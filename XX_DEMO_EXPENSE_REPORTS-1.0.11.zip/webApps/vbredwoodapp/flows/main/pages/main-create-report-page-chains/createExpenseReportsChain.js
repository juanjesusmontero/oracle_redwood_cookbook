define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createExpenseReportsChain extends ActionChain {

    /**
     * Saves changes and creates new expenseReports record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createExpenseReportsChainInProgress = true;

      try {
        // Validates expenseReports form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'expenseReports-validation-group--1268914578-1',
          },
        }, { id: 'validateExpenseReports' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new expenseReports record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_expenseReports/create_expenseReports',
          body: $page.variables.expenseReports,
        }, { id: 'saveExpenseReports' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new expenseReports: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'expenseReports saved',
          message: 'expenseReports record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets expenseReports variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.expenseReports',
          ],
        }, { id: 'resetExpenseReports' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createExpenseReportsChainInProgress = false;
      }
    }
  }

  return createExpenseReportsChain;
});
