/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     */
    async run(context) {
      const { $page, $variables } = context;
      await Actions.callChain(context, {
        chain: 'saveExpenseReportsChain',
        params: {
          expenseReportsId: $variables.objectId,
        },
      });

      // Reset dirty data
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.dirtyDataFlag',
        ],
      });

      $page.variables.isSaved = true;

      /*

      if ($page.variables.formState === 'valid') {
      } else {

        $variables.messages = 'demo1';

        await Actions.callComponentMethod(context, {
          selector: '#cdMessages',
          method: 'open',
        });        
      }
      */


    }
  }

  return spSaveChain;
});
