define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadExpenseReportsChain extends ActionChain {

    /**
     * Loads expenseReports record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.expenseReportsId 
     */
    async run(context, { expenseReportsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Loading.
      $page.variables.expenseReportsEditFormStatus = 'loading';

      try {
        // Tests the REST call can be initiated
        if (true && expenseReportsId !== undefined) {
          // Initiates REST call loading expenseReports data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'sn_expenseReports/get_expenseReports',
            responseType: 'getExpenseReportsResponse',
            uriParams: {
              'expenseReports_Id': expenseReportsId,
            },
          }, { id: 'loadExpenseReports' });

          if (!callRestResult.ok) {
            // Shows an error message informing about data load failure
            await Actions.fireNotificationEvent(context, {
              summary: 'Could not load data',
              message: 'Could not load data: status ' + callRestResult.status,
              displayMode: 'persist',
              type: 'error',
            }, { id: 'fireErrorNotification' });

            return;
          }

          // Assigns data loaded by the REST call to the expenseReports variable
          $page.variables.fetchedExpenseReports = callRestResult.body;

          // Assigns data loaded by the REST call to the expenseReports variable
          $page.variables.expenseReportsETag = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the expenseReports editable record variable
          $page.variables.expenseReports = $page.variables.fetchedExpenseReports;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.expenseReportsEditFormStatus = 'ready';
      }
    }
  }

  return loadExpenseReportsChain;
});
