/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions',
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSecondaryActionChain extends ActionChain {

    /**
     * Notifiy secondary action is triggered
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.detail Action detail
     */
    async run(context, { detail }) {
      const { $page, $variables } = context;

      // Assign the action detail to the message
      $page.variables.messages = "summary: Secondary Action Performed; " + "detail: secondaryItem: " + detail.secondaryItem + 'exp id:'+$variables.varExpenseId;

      // Show toast messages
      await Actions.callComponentMethod(context, {
        selector: '#cdMessages',
        method: 'open',
      }, { id: 'showToast' });


      if ( detail.secondaryItem === 'edit') {
        const toMainEditReport = await Actions.navigateToPage(context, {
          page: 'main-edit-report',
          params: {
            objectId: $variables.varExpenseReportId,
          },
        });
      }


      if ( detail.secondaryItem === 'create') {
        const toMainCreateReport = await Actions.navigateToPage(context, {
          page: 'main-create-report',
        });


      }      


    }

  }

  return spSecondaryActionChain;
});
