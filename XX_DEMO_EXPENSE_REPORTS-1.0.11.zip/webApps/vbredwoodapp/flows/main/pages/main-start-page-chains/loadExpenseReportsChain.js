define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadExpenseReportsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.expenseReportsId 
     */
    async run(context, { expenseReportsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      //if (true && expenseReportsId !== undefined) {
        
        // Clears expenseReports data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.var_ExpenseReport',
          ],
        }, { id: 'resetExpenseReportsData' });

      const response = await Actions.callRest(context, {
        endpoint: 'sn_expenseReports/get_expenseReports',
        uriParams: {
          'expenseReports_Id': $variables.varExpenseReportId,
        },
        responseBodyFormat: 'json',
      });

        // Initiates REST call loading expenseReports data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_expenseReports/get_expenseReports',
          responseType: 'getExpenseReportsResponse_type',
          uriParams: {
            'expenseReports_Id': $variables.varExpenseReportId,
          },
          responseBodyFormat: 'json',
        }, { id: 'loadExpenseReports' });

        /*
        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data- demo',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }*/

        // Assigns data loaded by the REST call to the expenseReports variable
        $page.variables.var_ExpenseReport = response.body;

      // }
    }
  }

  return loadExpenseReportsChain;
});
