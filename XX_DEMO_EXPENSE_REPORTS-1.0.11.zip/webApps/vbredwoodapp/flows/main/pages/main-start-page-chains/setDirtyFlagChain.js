/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
], ActionChain => {
  'use strict';

  class setDirtyFlagChain extends ActionChain {

    /**
     * Set dirty flag
     * @param {Object} context
     * @param {Object} params
     * @param {boolean} params.value 
     */
    async run(context, { value }) {
      const { $page } = context;

      $page.variables.dirtyDataFlag = value;
    }
  }

  return setDirtyFlagChain;
});
