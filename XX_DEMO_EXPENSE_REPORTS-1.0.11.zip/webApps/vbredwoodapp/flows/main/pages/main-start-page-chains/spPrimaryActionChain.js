/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions',
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spPrimaryActionChain extends ActionChain {

    /**
     * Notifiy primary action is triggered
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.detail Action detail
     */
    async run(context, { detail }) {
      const { $page, $variables } = context;

      // Assign the action detail to the message
      $page.variables.messages = "summary: Primary Action Performed; " + "detail: primaryItem: " + detail.actionId;

      // Show toast messages
      await Actions.callComponentMethod(context, {
        selector: '#cdMessages',
        method: 'open',
      }, { id: 'showToast' });

      if ( detail.actionId === 'edit') {
        const toMainEditReport = await Actions.navigateToPage(context, {
          page: 'main-edit-report',
          params: {
            objectId: $variables.varExpenseReportId,
          },
        });
      }


      
    }
  }

  return spPrimaryActionChain;
});
