define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toMainCreateExpense = await Actions.navigateToPage(context, {
        page: 'main-create-expense',
        params: {
          objectId: $variables.varExpenseReportId,
          varExpenseReportNumber: $variables.varExpenseReportNumber,
        },
      });
    }
  }

  return ButtonActionChain1;
});
