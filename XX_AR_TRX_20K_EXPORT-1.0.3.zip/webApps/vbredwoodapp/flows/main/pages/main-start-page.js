define([], () => {
  'use strict';

  class PageModule {
  }


  PageModule.prototype.add_adp = function (totalAdp, newAdp) {

    let varTotalAdp = totalAdp;

    for (let i = 0; i < newAdp.length; i++) {

      let ChargeComponentObj = {};
      ChargeComponentObj.BillToCustomerName = newAdp[i].BillToCustomerName;
      ChargeComponentObj.BusinessUnit = newAdp[i].BusinessUnit;
      ChargeComponentObj.CustomerTransactionId = newAdp[i].CustomerTransactionId;
      ChargeComponentObj.TransactionDate = newAdp[i].TransactionDate;
      ChargeComponentObj.TransactionNumber = newAdp[i].TransactionNumber;

      varTotalAdp.push(ChargeComponentObj);

    }

    return varTotalAdp;
    
  };


  return PageModule;
});

