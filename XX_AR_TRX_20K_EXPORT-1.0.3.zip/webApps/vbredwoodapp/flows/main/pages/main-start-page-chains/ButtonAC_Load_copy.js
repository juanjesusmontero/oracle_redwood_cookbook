define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonAC_Load_copy extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'sn_ar_trx/getall_receivablesInvoices',
        responseBodyFormat: 'json',
        responseType: 'getallReceivablesInvoicesResponse',
        uriParams: {
          limit: $variables.varLimit,
        },
      }, { id: 'fn00002' });

      $variables.varTrxArray_1 = response.body.items;

      const response2 = await Actions.callRest(context, {
        endpoint: 'sn_ar_trx/getall_receivablesInvoices',
        responseBodyFormat: 'json',
        responseType: 'getallReceivablesInvoicesResponse',
        uriParams: {
          offset: $variables.varOffset,
          limit: $variables.varLimit,
        },
      }, { id: 'fn00002' });

      $variables.varTrxArray_2 = response2.body.items;

      const addAdp = await $functions.add_adp($variables.varTrxArray_1, $variables.varTrxArray_2);

      $variables.varTrxArrayForAdp = addAdp;
    }
  }

  return ButtonAC_Load_copy;
});
