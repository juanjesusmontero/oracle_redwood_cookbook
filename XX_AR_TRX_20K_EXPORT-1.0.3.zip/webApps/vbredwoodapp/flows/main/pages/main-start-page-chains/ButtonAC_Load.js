define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonAC_Load extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.fireNotificationEvent(context, {
        summary: 'Info.',
        message: 'Loading ADP variable, it will take a while depending of the number of records requested. Check loops and max. loops for review.',
        displayMode: 'transient',
        type: 'info',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.varTrxArrayForAdp',
    '$page.variables.varTrxArray_1',
    '$page.variables.varTrxArray_2',
  ],
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.var_trx_ADP,
        refresh: null,
      });

      $variables.varGoOn = 'Y';
      $variables.varLoop = 0 ;
      $variables.varOffset = 0 ;
      $variables.varHasMore = true ;

      await this.callModuleFunctionFunction(context);

      await Actions.fireDataProviderEvent(context, {
        target: $variables.var_trx_ADP,
        refresh: null,
      });
      
    }

    /**
     * @param {Object} context
     */
    async callModuleFunctionFunction(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
    
      const callFunction = await this.demoF1(context);
    }

    /**
     * @param {Object} context
     */
    async demoF1(context) {
      const { $page, $flow, $application, $constants, $variables } = context;


      while ( $variables.varHasMore &&  $variables.varLoop < $variables.varMaxLoops )

      {

          console.log('hola loop:'+ $variables.varLoop);
          //$variables.varGoOn='N';          

          const response3 = await Actions.callRest(context, {
            endpoint: 'sn_ar_trx/getall_receivablesInvoices',
            responseBodyFormat: 'json',
            responseType: 'getallReceivablesInvoicesResponse',
            uriParams: {
              limit: $variables.varLimit,
              
              orderBy: 'CustomerTransactionId',
              onlyData: true,
              offset: $variables.varOffset,
            },
          }, { id: 'fn00003' });

          $variables.varTrxArray_2 = response3.body.items;

          const addAdp = await $page.functions.add_adp($variables.varTrxArray_1, $variables.varTrxArray_2);
          $variables.varTrxArray_1 = addAdp;
          
          console.log('demo zz0:' );          

          //$variables.varTotalRows = response3.body.totalResults;

          $variables.varHasMore = response3.body.hasMore;
          console.log('demo 0:'+' hasmore:'+ $variables.varHasMore );
          console.log('demo 2:'+' xx:'+ $variables.varTrxArray_1.length );
          console.log('demo 2:'+' xx:'+ $variables.varTrxArray_2.length );
          console.log('demo 2:'+' xx:'+ $variables.varTrxArrayForAdp.length );

          $variables.varOffset=Number($variables.varOffset)+Number($variables.varLimit);

          $variables.varLoop = $variables.varLoop + 1 ;

      }

      $variables.varTrxArrayForAdp = $variables.varTrxArray_1;
    
    }

  }

  return ButtonAC_Load;
  
});
