define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditTransferOrdersTransferOrderLinesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.transferOrdersTransferOrderLinesId
     */
    async run(context, { transferOrdersTransferOrderLinesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditTransferOrdersTransferOrderLinesResult = await Actions.navigateToPage(context, {
        page: 'main-edit-transfer-orders-transfer-order-lines',
        params: {
          transferOrdersTransferOrderLinesId: $variables.varLineId,
          pHeaderId: $variables.varHeaderId,
        },
      });
    }
  }

  return navigateToEditTransferOrdersTransferOrderLinesChain;
});
