define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadTransferOrdersTransferOrderLinesChain extends ActionChain {

    /**
     * Loads transferOrders/transferOrderLines record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.transferOrdersId 
     * @param {string} params.transferOrdersTransferOrderLinesId 
     */
    async run(context, { transferOrdersId, transferOrdersTransferOrderLinesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Loading.
      $page.variables.transferOrdersTransferOrderLinesEditFormStatus = 'loading';

      try {
        // Tests the REST call can be initiated
        if (true && transferOrdersId !== undefined && transferOrdersTransferOrderLinesId !== undefined) {
          // Initiates REST call loading transferOrders/transferOrderLines data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'serv_transferOrders/get_transferOrders-transferOrderLines',
            responseType: 'getTransferOrdersTransferOrderLinesResponse',
            uriParams: {
              'transferOrders_Id': transferOrdersId,
              'transferOrders_transferOrderLines_Id': transferOrdersTransferOrderLinesId,
            },
          }, { id: 'loadTransferOrdersTransferOrderLines' });

          if (!callRestResult.ok) {
            // Shows an error message informing about data load failure
            await Actions.fireNotificationEvent(context, {
              summary: 'Could not load data',
              message: 'Could not load data: status ' + callRestResult.status,
              displayMode: 'persist',
              type: 'error',
            }, { id: 'fireErrorNotification' });

            return;
          }

          // Assigns data loaded by the REST call to the transferOrders/transferOrderLines variable
          $page.variables.fetchedTransferOrdersTransferOrderLines = callRestResult.body;

          // Assigns data loaded by the REST call to the transferOrders/transferOrderLines variable
          $page.variables.transferOrdersTransferOrderLinesETag = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the transferOrders/transferOrderLines editable record variable
          $page.variables.transferOrdersTransferOrderLines = $page.variables.fetchedTransferOrdersTransferOrderLines;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.transferOrdersTransferOrderLinesEditFormStatus = 'ready';
      }

      $variables.varSourceInvOrgId = $variables.transferOrdersTransferOrderLines.SourceOrganizationId;
    }
  }

  return loadTransferOrdersTransferOrderLinesChain;
});
