/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSubmitChain extends ActionChain {

    /**
     * Notify primary action is triggered
     * @param {Object} context
     */
    async run(context) {
      const { $variables } = context;

      // Call save chain
      await Actions.callChain(context, {
        chain: 'saveTransferOrdersTransferOrderLinesChain',
        params: {
          transferOrdersId: $variables.pHeaderId,
          transferOrdersTransferOrderLinesId: $variables.pLineId,
        },
      }, { id: 'callSaveChain' });

      // Navigate to page
      const toMainStart = await Actions.navigateToPage(context, {
        page: 'main-start',
      }, { id: 'navigateToPage' });
    }
  }

  return spSubmitChain;
});
