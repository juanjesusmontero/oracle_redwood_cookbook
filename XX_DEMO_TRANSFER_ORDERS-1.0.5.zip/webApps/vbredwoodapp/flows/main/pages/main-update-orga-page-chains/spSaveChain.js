/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     */
    async run(context) {
      const { $page, $variables } = context;

      if ($page.variables.formState === 'valid') {
        await Actions.callChain(context, {
          chain: 'saveTransferOrdersTransferOrderLinesChain',
          params: {
            transferOrdersId: $variables.pHeaderId,
            transferOrdersTransferOrderLinesId: $variables.pLineId,
          },
        });

        // Reset dirty data
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.dirtyDataFlag',
          ],
        });

        $page.variables.isSaved = true;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'demo1',
          message: 'demo1',
          displayMode: 'transient',
          type: 'info',
        });

        await Actions.callComponentMethod(context, {
          selector: 'oj-dynamic-form',
          method: 'showMessages',
        });
        
      }
    }
  }

  return spSaveChain;
});
