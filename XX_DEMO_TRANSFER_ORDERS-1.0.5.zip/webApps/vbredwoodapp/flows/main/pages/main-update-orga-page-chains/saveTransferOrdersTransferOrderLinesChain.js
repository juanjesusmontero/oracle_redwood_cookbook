define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveTransferOrdersTransferOrderLinesChain extends ActionChain {

    /**
     * Saves transferOrders/transferOrderLines record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.transferOrdersId 
     * @param {string} params.transferOrdersTransferOrderLinesId 
     */
    async run(context, { transferOrdersId, transferOrdersTransferOrderLinesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Saving.
      $page.variables.transferOrdersTransferOrderLinesEditFormStatus = 'saving';

      try {
        // Validates transferOrders/transferOrderLines form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'transferOrdersTransferOrderLines-validation-group-65449930-1',
          },
        }, { id: 'validateTransferOrdersTransferOrderLines' });

        if (!validateFormResult) {
          return;
        }

        $variables.transferOrdersTransferOrderLines.SourceOrganizationId = $variables.varSourceInvOrgId;

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.transferOrdersTransferOrderLines,
          fetchedRecord: $page.variables.fetchedTransferOrdersTransferOrderLines,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        // Initiates REST call saving transferOrders/transferOrderLines data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'serv_transferOrders/update_transferOrders-transferOrderLines',
          body: payload,
          headers: $page.variables.transferOrdersTransferOrderLinesETag ? { 'If-Match': $page.variables.transferOrdersTransferOrderLinesETag } : null,
          requestType: 'json',
          uriParams: {
            'transferOrders_Id': transferOrdersId,
            'transferOrders_transferOrderLines_Id': transferOrdersTransferOrderLinesId,
          },
        }, { id: 'saveTransferOrdersTransferOrderLines' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not edit transferOrders/transferOrderLines: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'transferOrders/transferOrderLines saved',
          message: 'transferOrders/transferOrderLines record successfully updated',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Calls action chain re-loading transferOrders/transferOrderLines data
        await Actions.callChain(context, {
          chain: 'loadTransferOrdersTransferOrderLinesChain',
          params: {
            transferOrdersId: $page.variables.pHeaderId,
            transferOrdersTransferOrderLinesId: $page.variables.pLineId,
          },
        }, { id: 'callLoadTransferOrdersTransferOrderLinesChain' });
      } finally {
        // Updates form status to Ready.
        $page.variables.transferOrdersTransferOrderLinesEditFormStatus = 'ready';
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveTransferOrdersTransferOrderLinesChain;
});
