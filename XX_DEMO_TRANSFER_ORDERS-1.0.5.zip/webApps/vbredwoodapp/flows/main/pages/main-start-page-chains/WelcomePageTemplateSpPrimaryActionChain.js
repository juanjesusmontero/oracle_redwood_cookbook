define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toMainUpdateOrga = await Actions.navigateToPage(context, {
        page: 'main-update-orga',
        params: {
          pHeaderId: $variables.varHeaderId,
          pLineId: $variables.varLineId,
        },
      });
    }
  }

  return WelcomePageTemplateSpPrimaryActionChain;
});
