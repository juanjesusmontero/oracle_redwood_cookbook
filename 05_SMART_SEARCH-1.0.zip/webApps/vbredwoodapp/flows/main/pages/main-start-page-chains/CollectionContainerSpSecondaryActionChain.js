define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionContainerSpSecondaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.actionId 
     */
    async run(context, { actionId }) {
      const { $page, $flow, $application } = context;

      if (actionId === 'edit') {
        if ($page.variables.oj_list_view_1896815765_1SelectedId !== '1') {

          const toEditStart = await Actions.navigateToPage(context, {
            page: 'edit-start',
            params: {
              empId: $page.variables.oj_list_view_1896815765_1SelectedId,
            },
          });
        }
      }
    }
  }

  return CollectionContainerSpSecondaryActionChain;
});
