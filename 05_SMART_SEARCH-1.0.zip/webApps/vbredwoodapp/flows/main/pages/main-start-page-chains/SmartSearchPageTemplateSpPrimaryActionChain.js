define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SmartSearchPageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      await Actions.fireNotificationEvent(context, {
        summary: 'Info.',
        message: 'Hello the id. of your selected record is:'+$page.variables.oj_list_view_1896815765_1SelectedId,
        displayMode: 'transient',
        type: 'info',
      });
    }
  }

  return SmartSearchPageTemplateSpPrimaryActionChain;
});
