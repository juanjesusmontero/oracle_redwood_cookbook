define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toMainSearchFold = await Actions.navigateToPage(context, {
        page: 'main-search-fold',
        params: {
          parentPage: 'main-search-start',
          selectedPanel: 1,
          paramEmpId: $variables.currentEmpId,
          rowIndex: 0,
        },
      });
    }
  }

  return WelcomePageTemplateSpPrimaryActionChain;
});
