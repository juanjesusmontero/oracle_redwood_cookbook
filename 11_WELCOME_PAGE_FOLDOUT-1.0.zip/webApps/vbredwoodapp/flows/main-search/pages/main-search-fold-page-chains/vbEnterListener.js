define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $chain } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_Employee',
        uriParams: {
          'Employee_Id': $variables.paramEmpId,
        },
        responseBodyFormat: 'json',
        responseType: 'get_Employee',
      });

      $variables.varEmp = response.body;
    }
  }

  return vbEnterListener;
});
