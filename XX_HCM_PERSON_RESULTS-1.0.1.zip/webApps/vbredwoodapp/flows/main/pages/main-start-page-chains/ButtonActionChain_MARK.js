define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain_MARK extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        displayMode: 'transient',
        type: 'info',
        message: 'Process running, please wait.',
      });

      $variables.varPerformPR.actionName = 'MARK_FOR_RETRY';

      const response = await Actions.callRest(context, {
        endpoint: 'sn_processResults/do_performObjectAction_personProcessResults',
        uriParams: {
          'personProcessResults_Id': $variables.varObjectActionId,
        },
        body: $variables.varPerformPR,
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Info',
        displayMode: 'transient',
        type: 'info',
        message: 'Result:'+response.status+' '+response.statusText,
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.objectProcessResultsListSDP,
      });
    }
  }

  return ButtonActionChain_MARK;
});
