define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $base, $extension, $constants, $variables, $functions, $chain, $modules } = context;

      const headerId = await $functions.getHeaderId();
      $variables.varHeaderId = headerId;

      await $functions.createPopup('Do you want to navigate to Additional information page?', function () {

        console.log('yes-------');
        $variables.varReponse = '1';
        const toMoredataforso = Actions.navigateToApplication(context, {
          application: 'moredataforso',
          params: {
            'pHeaderId_app': $variables.varHeaderId,
          },
        });

      },
        function () {
          // Code for No click
          console.log('no-------');
          $variables.varReponse = '2';
        });

      if ($variables.varReponse === '1') {

        const toMoredataforso = await Actions.navigateToApplication(context, {
          application: 'moredataforso',
          params: {
            'pHeaderId_app': $variables.varHeaderId,
          },
        });

      }

    }
  }

  return vbEnterListener;
});
