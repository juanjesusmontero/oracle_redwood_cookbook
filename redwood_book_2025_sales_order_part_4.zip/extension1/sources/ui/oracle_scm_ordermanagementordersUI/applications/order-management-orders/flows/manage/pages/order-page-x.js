define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.getHeaderId = function () {

    let a = location.href;
    let b = a.indexOf("headerId");
    let d = a.substring(b + 8);
    let c = d.indexOf("&mode");
    let e = d.substring(1, c);
    return e;
  };

  PageModule.prototype.smallAlert = function () {

    /* OLD VERSION */

    let text;
    if (confirm("Press Accept to navigate to a page with Sales Order Details") === true) {
      text = "Selected_1";
    } else {
      text = "Selected_2";
    }

    return (text);

  };

  PageModule.prototype.createPopup = function (message, onYes, onNo) {

      /* ---------------------------------------------------------------------
      NEW VERSION. CLEANER AND NICER.c
      ALL CREDIT FOR >>>>>>>>>>  Mohammed Galal-WIND-IS. 2025
      ---------------------------------------------------------------------  */
      const popup = `
          <div style="
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5);
              display: flex;
              justify-content: center;
              align-items: center;
              z-index: 1000;">
              
              <div style="
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                  width: 100%;
                  max-width: 400px;
                  position: relative;">
                  
                  <div style="
                      font-size: 18px;
                      margin-bottom: 15px;
                      color: #333;">
                      Confirm Action
                  </div>
                  
                  <div style="
                      margin-bottom: 20px;
                      color: #666;">
                      ${message}
                  </div>
                  
                  <div style="
                      display: flex;
                      justify-content: flex-end;
                      gap: 10px;">
                      
                      <button id="popupNo" style="
                          padding: 8px 16px;
                          border-radius: 4px;
                          cursor: pointer;
                          border: none;
                          font-size: 14px;
                          background-color: #f0f0f0;
                          color: #333;">
                          No
                      </button>
                      
                      <button id="popupYes" style="
                          padding: 8px 16px;
                          border-radius: 4px;
                          cursor: pointer;
                          border: none;
                          font-size: 14px;
                          background-color: #333;
                          color: white;">
                          Yes
                      </button>
                  </div>
              </div>
          </div>
      `;

      const container = document.createElement('div');
      container.innerHTML = popup;
      document.body.appendChild(container);

      const noBtn = container.querySelector('#popupNo');
      const yesBtn = container.querySelector('#popupYes');

      noBtn.addEventListener('click', () => {
        if (onNo) onNo();
        container.remove();
      });

      yesBtn.addEventListener('click', () => {
        if (onYes) onYes();
        container.remove();
      });


  };

  PageModule.prototype.getBatchId = function () {
    let today = new Date();

    let mo = (today.getMonth() + 1);
    if (mo < 10) {
      mo = '0' + mo;
    }

    let da = today.getDate();
    if (da < 10) {
      da = '0' + da;
    }

    let hh = today.getHours();
    if (hh < 10) {
      hh = '0' + hh;
    }

    let mi = today.getMinutes();
    if (mi < 10) {
      mi = '0' + mi;
    }

    let ss = today.getSeconds();
    if (ss < 10) {
      ss = '0' + ss;
    }

    let date = today.getFullYear() + '_' + mo + '_' + da;
    let time = hh + '_' + mi + '_' + ss;

    return (date + '_' + time);
  };

  return PageModule;
});
