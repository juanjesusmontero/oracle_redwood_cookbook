define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable9488176751ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.departmentsId
     */
    async run(context, { departmentsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_948817675_1SelectedId = departmentsId;
    }
  }

  return ojTable9488176751ChangeSelectionChain;
});
