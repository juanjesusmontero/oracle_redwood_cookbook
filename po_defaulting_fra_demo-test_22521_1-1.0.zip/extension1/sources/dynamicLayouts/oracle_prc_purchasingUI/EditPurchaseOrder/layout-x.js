define([], () => {
  'use strict';

  class LayoutModule {
  }


  LayoutModule.prototype.default_js = function () {
    alert('Hi from VB_REDWOOD_COOKBOOK_2025-1-layout');
  };

  LayoutModule.prototype.getPoHeaderId = function () {    
    let a = location.href;
    let b = a.indexOf("poHeaderId");
    let d = a.substring(b + 11);
    alert('Hi from VB_REDWOOD_COOKBOOK_2025-2. po_id:' + d);    
    return d;    
  };



  return LayoutModule;
});
