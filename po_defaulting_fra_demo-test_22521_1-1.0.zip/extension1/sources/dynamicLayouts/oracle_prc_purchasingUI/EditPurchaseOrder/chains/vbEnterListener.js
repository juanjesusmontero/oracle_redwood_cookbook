define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $layout, $base, $extension, $responsive, $user, $constants, $variables, $functions } = context;

      if (1 === '2') {

        await $functions.default_js();

        await Actions.callChain(context, {
          chain: 'demoUpdateDefaults',
        });
      }
      
    }
  }

  return vbEnterListener;
});
