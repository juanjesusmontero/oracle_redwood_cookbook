define([], () => {
  'use strict';

  class FragmentModule {
  }


  PageMFragmentModuleodule.prototype.default_js = function () {

    //alert('Hi from VB_REDWOOD_COOKBOOK_2025-2X');

    console.log("12345");

    /*document.getElementById("oj-dyn-form--1548467804-1_fl_draftPurchaseOrders.Description").setAttribute("hint") = "aa";
    document.getElementById("oj-dyn-form--1548467804-1_fl_draftPurchaseOrders.Description").setAttribute("value") = "aakdkdkdk";
    document.getElementById("oj-dyn-form--1548467804-1_fl_draftPurchaseOrders.Description").hint = "HI";
    document.getElementById("oj-dyn-form--1548467804-1_fl_draftPurchaseOrders.Description").focus;
*/
    

    console.log("67890");

  };


  return FragmentModule;
});
