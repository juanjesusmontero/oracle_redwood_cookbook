define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class findCountryG extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.pPartyId 
     * @return {string} 
     */
    async run(context, { pPartyId }) {
      const { $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'sn_orgs/getall_hubOrganizations',
        uriParams: {
          q: 'PartyId='+ pPartyId,
        },
      });

      const results = await ActionUtils.forEach(response.body.items, async (item, index) => {

        $variables.varCountryG = item.Country;
      }, { mode: 'serial' });

      return $variables.varCountryG;

    }
  }

  return findCountryG;

});
