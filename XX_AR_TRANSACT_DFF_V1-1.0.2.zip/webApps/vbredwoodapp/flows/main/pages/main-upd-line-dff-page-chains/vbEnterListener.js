define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const findCountryG = await Actions.callChain(context, {
        chain: 'application:findCountryG',
        params: {
          pPartyId: $variables.pPartyId,
        },
      });

      $variables.varCountry = findCountryG;

      const response = await Actions.callRest(context, {
        endpoint: 'sn_ar_trx/getall_receivablesInvoices-receivablesInvoiceLines-receivablesInvoiceLineDFF',
        uriParams: {
          'receivablesInvoices_Id': $variables.pTrxId,
          'receivablesInvoices_receivablesInvoiceLines_Id': $variables.pTrxLineId,
        },
      });

      $variables.receivablesInvoicesLineDFF.demoRedwood = response.body.items[0].demoRedwood;
    }
  }

  return vbEnterListener;
});
