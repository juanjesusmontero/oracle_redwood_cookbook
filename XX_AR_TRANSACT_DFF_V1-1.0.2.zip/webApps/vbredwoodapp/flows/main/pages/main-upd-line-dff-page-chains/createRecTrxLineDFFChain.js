define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createRecTrxLineDFFChain extends ActionChain {

    /**
     * Saves changes and creates new receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createRecLineDFFChainInProgress = true;

      try {
        // Validates receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'receivablesInvoicesReceivablesInvoiceLinesReceivablesInvoiceLineDFF-validation-group-1256836448-1',
          },
        }, { id: 'validateReceivablesInvoicesReceivablesInvoiceLinesReceivablesInvoiceLineDFF' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_ar_trx/create_receivablesInvoices-receivablesInvoiceLines-receivablesInvoiceLineDFF',
          body: $page.variables.receivablesInvoicesLineDFF,
          uriParams: {
            'receivablesInvoices_Id': $variables.pTrxId,
            'receivablesInvoices_receivablesInvoiceLines_Id': $variables.pTrxLineId,
          },
        }, { id: 'saveReceivablesInvoicesReceivablesInvoiceLinesReceivablesInvoiceLineDFF' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF saved',
          message: 'receivablesInvoices/receivablesInvoiceLines/receivablesInvoiceLineDFF record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets receivablesInvoicesReceivablesInvoiceLinesReceivablesInvoiceLineDFF variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.receivablesInvoicesLineDFF',
          ],
        }, { id: 'resetReceivablesInvoicesReceivablesInvoiceLinesReceivablesInvoiceLineDFF' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createRecLineDFFChainInProgress = false;
      }
    }
  }

  return createRecTrxLineDFFChain;
});
