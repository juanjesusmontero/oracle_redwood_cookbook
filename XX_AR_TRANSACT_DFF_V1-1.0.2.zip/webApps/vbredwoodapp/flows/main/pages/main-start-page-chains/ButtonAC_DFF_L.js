define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonAC_DFF_L extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toMainUpdLineDff = await Actions.navigateToPage(context, {
        page: 'main-upd-line-dff',
        params: {
          pTrxId: $variables.varTrxId,
          pTrxLineId: $variables.varTrxLineId,
          pPartyId: $variables.varPartyId,
          pTransactionNumber: $variables.varTransactionNumber,
          pLineNumber: $variables.varLineNumber,
        },
      });
    }
  }

  return ButtonAC_DFF_L;
});
