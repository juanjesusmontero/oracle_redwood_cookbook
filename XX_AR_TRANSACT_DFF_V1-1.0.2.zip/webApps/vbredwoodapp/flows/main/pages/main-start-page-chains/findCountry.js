define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class findCountry extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.pPartyId 
     * @return {string} 
     */
    async run(context, { pPartyId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'sn_orgs/getall_hubOrganizations',
        uriParams: {
          q: 'PartyId='+ pPartyId,
        },
        responseBodyFormat: 'json',
        responseType: 'getall_hubOrganizations',
      });

      const results = await ActionUtils.forEach(response.body.itemsresponse.body.items, async (item, index) => {

        $variables.varCountry = 'item.Country';
      }, { mode: 'serial' });

      return $variables.varCountry;
    }
  }

  return findCountry;
});
