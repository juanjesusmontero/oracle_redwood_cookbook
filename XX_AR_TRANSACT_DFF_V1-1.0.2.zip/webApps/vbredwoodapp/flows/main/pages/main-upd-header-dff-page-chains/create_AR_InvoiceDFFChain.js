define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class create_AR_InvoiceDFFChain extends ActionChain {

    /**
     * Saves changes and creates new receivablesInvoices/receivablesInvoiceDFF record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createReceivablesInvoicesReceivablesInvoiceDFFChainInProgress = true;

      try {
        // Validates receivablesInvoices/receivablesInvoiceDFF form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'receivablesInvoicesReceivablesInvoiceDFF-validation-group--1848924151-1',
          },
        }, { id: 'validateReceivablesInvoicesReceivablesInvoiceDFF' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new receivablesInvoices/receivablesInvoiceDFF record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'sn_ar_trx/create_receivablesInvoices-receivablesInvoiceDFF',
          body: $page.variables.var_AR_InvoiceDFF,
          uriParams: {
            'receivablesInvoices_Id': $variables.objectId,
          },
        }, { id: 'saveReceivablesInvoicesReceivablesInvoiceDFF' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new receivablesInvoices/receivablesInvoiceDFF: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'receivablesInvoices/receivablesInvoiceDFF saved',
          message: 'receivablesInvoices/receivablesInvoiceDFF record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets receivablesInvoicesReceivablesInvoiceDFF variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.var_AR_InvoiceDFF',
          ],
        }, { id: 'resetReceivablesInvoicesReceivablesInvoiceDFF' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createReceivablesInvoicesReceivablesInvoiceDFFChainInProgress = false;
      }
    }
  }

  return create_AR_InvoiceDFFChain;
});
