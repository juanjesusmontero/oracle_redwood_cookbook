/* eslint-disable dot-notation */
define([], () => {
  'use strict';

  /**
   * Default value expression for positionsV2.positionsDFF.demoRedwood 
   * @param {object} context
   * @return {string}
   */
  function getPositionsV2PositionsDFFDemoRedwood(context) {
    const { $componentContext, $fields, $modules, $user } = context;

    
    let a = $fields.positionsV2.DepartmentId.$numberValue() + '';


    if ( $fields.positionsV2.DepartmentId.$numberValue() > 0 ) {
      return a ;
    }
    else {
      return 'Not defined yet';
    }

  }

  return { getPositionsV2PositionsDFFDemoRedwood };
  
});
