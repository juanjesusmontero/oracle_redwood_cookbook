define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadEmployeeChain extends ActionChain {

    /**
     * Loads Employee record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeId 
     */
    async run(context, { employeeId }) {
      const { $page, $flow, $application } = context;

      // Updates form status to Loading.
      $page.variables.employeeEditFormStatus = 'loading';

      try {
        // Tests the REST call can be initiated
        if (true && employeeId !== undefined) {
          // Initiates REST call loading Employee data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/get_Employee',
            responseType: 'getEmployeeResponse',
            uriParams: {
              'Employee_Id': employeeId,
            },
          }, { id: 'loadEmployee' });

          if (!callRestResult.ok) {
            // Shows an error message informing about data load failure
            await Actions.fireNotificationEvent(context, {
              summary: 'Could not load data',
              message: 'Could not load data: status ' + callRestResult.status,
              displayMode: 'persist',
              type: 'error',
            }, { id: 'fireErrorNotification' });

            return;
          }

          // Assigns data loaded by the REST call to the Employee variable
          $page.variables.fetchedEmployee = callRestResult.body;

          // Assigns data loaded by the REST call to the Employee variable
          $page.variables.employeeETag = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the Employee editable record variable
          $page.variables.employee = $page.variables.fetchedEmployee;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.employeeEditFormStatus = 'ready';
      }
    }
  }

  return loadEmployeeChain;
});
