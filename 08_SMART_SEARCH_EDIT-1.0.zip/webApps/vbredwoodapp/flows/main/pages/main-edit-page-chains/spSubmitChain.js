/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSubmitChain extends ActionChain {

    /**
     * Notify primary action is triggered
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      // Call save chain
      await Actions.callChain(context, {
        chain: 'saveEmployeeChain',
        params: {
          employeeId: $page.variables.objectId,
        },
      }, { id: 'callSaveChain' });

      // Navigate to page
      const toShell = await Actions.navigateToPage(context, {
        page: '/shell',
      }, { id: 'navigateToPage' });
    }
  }

  return spSubmitChain;
});
